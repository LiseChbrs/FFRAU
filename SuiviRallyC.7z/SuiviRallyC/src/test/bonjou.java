package test;

public class bonjou {
/***
 * Sa mere la gentille personne
 */
}
