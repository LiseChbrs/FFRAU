package GestionRallye;

public enum TypeRegleSpecial {speciale, superSpeciale}
