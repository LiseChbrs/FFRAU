package GestionDonnees;
public enum Difficulte {
	sans_difficulte_particuliere,
	difficulte_mineures,
	difficulte_moyenne,
	difficile,
	tres_difficile
}



