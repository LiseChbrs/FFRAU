package GestionDonnees;

public enum Etat {
	ouvertAuxInscriptions,
	debute,
	clos
}
