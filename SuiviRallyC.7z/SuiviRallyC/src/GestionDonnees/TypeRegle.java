package GestionDonnees;

public enum TypeRegle {
	rallye,
	superRallye
}

