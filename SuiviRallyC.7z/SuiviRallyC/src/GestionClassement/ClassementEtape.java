package GestionClassement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import GestionDonnees.Etat;
import GestionInscription.Camion;
import GestionInscription.Coureur;
import GestionInscription.Voiture;
import GestionRallye.Etape;
import GestionRallye.Speciale;;

public class ClassementEtape {

	private HashMap<Coureur,ArrayList<SpecialTemps>> listTemps;
	private HashMap<Coureur,Rapport> listRapport;
	private Etape etape;

	public ClassementEtape(Etape etape) {
		this.listTemps = new HashMap<Coureur, ArrayList<SpecialTemps>>();
		this.etape = etape;
		this.listRapport = new HashMap<Coureur, Rapport>();
	}

	public void enregistrerTemps(Coureur c, Speciale s, Double t) {
		if(this.etape.getEtat().equals(Etat.debute)) {
			if(this.listTemps.containsKey(c)) {
				this.listTemps.get(c).add(new SpecialTemps(s,t));
			}else {
				ArrayList<SpecialTemps> spt = new ArrayList<SpecialTemps>();
				spt.add(new SpecialTemps(s,t));
				this.listTemps.put(c, spt);
			}
		}else {
			System.out.println("ETAPE CLOSE.");
		}
	}

	/***
	 * Si on a d�j� un rapport on voir pour ajouter les p�nalit�s si
	 * le coureur n'est pas �limin�.
	 * Sinon, il nous suffit d'ajouter un nouveau rapport.
	 * @param c
	 * @param r
	 */
	public void enregistrerRapport(Coureur c, Rapport r) {
		if(this.listRapport.containsKey(c)) {
			if(r.getelimine()) {
				this.listRapport.put(c, r);
			}else {
				r.penalitetps += this.listRapport.get(c).penalitetps;
				this.listRapport.put(c, r);
			}
		}else {
			this.listRapport.put(c, r);
		}
	}	



	public double calculerTempsCoef(double temps) {
		double coeff = this.etape.getCoeffDiff();
		return temps * coeff;
	}


	public ArrayList<Couple> calculerClassement() {
		this.etape.setEtat(Etat.clos);
		ArrayList<Couple> classement = new ArrayList<Couple>();
		for(Entry<Coureur, ArrayList<SpecialTemps> > e : this.listTemps.entrySet()) {
			double somme =0;
			for(SpecialTemps s : e.getValue()) {
				somme += s.getValue();
			}
			//ON AFFECTE LE TEMPS SELON LE RAPPORT
			if(this.listRapport.containsKey(e.getKey())) {
				Rapport r = this.listRapport.get(e.getKey());
				//Si on a une �limination on le retire de la liste.
				if(r.getelimine()) {
					System.out.println(e.getKey().getNomC()+" "+e.getKey().getPrenomC()+" est �limin�");
				}else {
					//Sinon on lui impute une �ventuelle p�nalit�/Bonus(selon le signe).
					somme += r.getPenalite();
				}

			}
			//On ins�re dans le classement.Permet d'avoir le temps minor� selon le coefficient.
			somme = this.calculerTempsCoef(somme);
			classement.add(new Couple(e.getKey(),somme));
		}
		for(int i =0;i<classement.size();i++) {
			Couple c = classement.get(i);
			if(this.listRapport.containsKey(c.getKey())) {
				Rapport r  = this.listRapport.get(c.getKey());
				if(r.getelimine()) {
					classement.remove(i);
					i--;
				}
			}
		}

		//Il faut ensuite trier le classement.
		Collections.sort(classement, (c1,c2) -> c1.getValue().compareTo(c2.getValue()));
		return classement;
	}

	/***
	 * Retourne un hashmap de classements tri�s par type de v�hicule.
	 * Accessible par String : "Voiture","Moto","Camion".
	 * @return
	 */
	public HashMap<String,ArrayList<Couple>> getClassementByVehicule(){
		HashMap<String,ArrayList<Couple>> sorted = new HashMap<String, ArrayList<Couple>>();
		ArrayList<Couple> r = this.calculerClassement();
		ArrayList<Couple> voitures = new ArrayList<>();
		ArrayList<Couple> motos = new ArrayList<>();
		ArrayList<Couple> camions = new ArrayList<>();

		for(Couple c : r) {
			if(c.getKey().getVehicule() instanceof Voiture) {
				voitures.add(c);
			}else if(c.getKey().getVehicule() instanceof Camion) {
				camions.add(c);
			}else {
				motos.add(c);
			}
		}
		Collections.sort(voitures, (c1,c2) -> c1.getValue().compareTo(c2.getValue()));
		Collections.sort(camions, (c1,c2) -> c1.getValue().compareTo(c2.getValue()));
		Collections.sort(motos, (c1,c2) -> c1.getValue().compareTo(c2.getValue()));

		sorted.put("Voiture", voitures);
		sorted.put("Moto",motos);
		sorted.put("Camion",camions);
		return sorted;
	}




	public HashMap<Coureur, ArrayList<SpecialTemps>> getListTemps() {
		return listTemps;
	}

	public HashMap<Coureur, Rapport> getListRapport() {
		return listRapport;
	}

	public Etape getEtape() {
		return etape;
	}



}