module SuiviRallyC {
	requires java.desktop;
	requires jdk.jdi;
	requires java.sql;
	//requires jdk.compiler;
	//requires java.net.http;
}