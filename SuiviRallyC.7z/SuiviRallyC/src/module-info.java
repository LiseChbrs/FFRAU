module SuiviRallyC {
	//requires jdk.compiler;
	//requires java.net.http;
}